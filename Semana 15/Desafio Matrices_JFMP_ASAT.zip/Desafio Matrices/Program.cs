﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

class CAMPEONATOFUTBOL
{
    //PAREJA: JORGE MUÑOZ Y SOFIA ASTURIAS
    static void Main(string[] args)
    {       
        Console.WriteLine("¿De cuantos equipos va a ser el campeonato?: ");
        int equipos = Convert.ToInt32(Console.ReadLine());

        int[,] partidos = new int[equipos, 6];
        string[] vectornombres = new string[equipos];
        Random r = new Random();

        try
        {
            for (int i = 0; i < equipos; i++)
            {
                Console.Write("Ingrese el nombre de cada equipo: ");
                string nombres = Console.ReadLine();

                while (vectornombres.Contains(nombres))
                {
                    Console.WriteLine("El nombre que ingresó ya existe. Ingrese un nombre diferente: ");
                    Console.Write("-> ");
                    nombres = Console.ReadLine();
                }
                vectornombres[i] = nombres;
            }

            Console.Clear();
            Console.WriteLine(" --- TABLA DE EQUIPOS --- \n");
            for (int i = 0; i < equipos; i++)
            {
                int cont = i + 1;
                Console.WriteLine("Equipo No. " + cont + ": " + vectornombres[i]);
            }

            int[,] estadisticas = new int[equipos, 7];
            for (int i = 0; i < equipos; i++)
            {
                estadisticas[i, 0] = r.Next(1, 15);
                estadisticas[i, 1] = r.Next(1, 15);
                estadisticas[i, 2] = r.Next(1, 15);
                estadisticas[i, 3] = r.Next(1, 15);
                estadisticas[i, 4] = r.Next(1, 15);
                estadisticas[i, 5] = r.Next(1, 15);
                estadisticas[i, 6] = r.Next(1, 15);

                Console.WriteLine("");
                Console.WriteLine(vectornombres[i] + "\t Jugados: " + estadisticas[i, 1] + "\t Ganados: " + estadisticas[i, 2] + "\t Empatados: " + estadisticas[i, 3] + "\t Perdidos: " + estadisticas[i, 4] + "\t Goles a favor: " + estadisticas[i, 5] + "\t Goles en contra: " + estadisticas[i, 6]);
            }         
        }
        catch
        {
            Console.WriteLine("Ingrese números que NO sean negativos.");
        }        
    }
}

