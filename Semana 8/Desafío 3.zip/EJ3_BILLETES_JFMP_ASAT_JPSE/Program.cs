﻿using System;

class Program
{
    static void Main()
    {        
        double multi1 = 0, b5 = 0;
        double multi2 = 0, b10 = 0;
        double multi3 = 0, b20 = 0;
        double multi4 = 0, b50 = 0;
        double multi5 = 0, b100 = 0;
        double multi6 = 0, b200 = 0;
        double multi7 = 0, m5 = 0;
        double multi8 = 0, m10 = 0;
        double multi9 = 0, m25 = 0;
        double multi10 = 0, m50 = 0;
        double multi11 = 0, m100 = 0;

        string opcion = "0";
        while (opcion == "0")
        {
            Console.Clear();
            Console.WriteLine("Jorge Muñoz - Sofia Asturias - José Sosa");
            Console.WriteLine("\nIngrese una opción: \n");

            Console.WriteLine("BILLETES");
            Console.WriteLine("1. Billetes de 5.");
            Console.WriteLine("2. Billetes de 10.");
            Console.WriteLine("3. Billetes de 20.");
            Console.WriteLine("4. Billetes de 50.");
            Console.WriteLine("5. Billetes de 100.");
            Console.WriteLine("6. Billetes de 200.\n");

            Console.WriteLine("MONEDAS");
            Console.WriteLine("7. Monedas de 5 centavos.");
            Console.WriteLine("8. Monedas de 10 centavos.");
            Console.WriteLine("9. Monedas de 25 centavos.");
            Console.WriteLine("10. Monedas de 50 centavos.");
            Console.WriteLine("11. Monedas de 1 quetzal.\n");
            Console.WriteLine("13. Salir del programa.");

            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine("Billetes de 5.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b5 = Convert.ToDouble(Console.ReadLine());
                    multi1 = b5 * 5;
                    Console.WriteLine("Valor total: Q" + multi1);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "2":
                    Console.Clear();
                    Console.WriteLine("Billetes de 10.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b10 = Convert.ToDouble(Console.ReadLine());
                    multi2 = b10 * 10;
                    Console.WriteLine("Valor total: Q" + multi2);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "3":
                    Console.Clear();
                    Console.WriteLine("Billetes de 20.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b20 = Convert.ToDouble(Console.ReadLine());
                    multi3 = b20 * 20;
                    Console.WriteLine("Valor total: Q" + multi3);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "4":
                    Console.Clear();
                    Console.WriteLine("Billetes de 50.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b50 = Convert.ToDouble(Console.ReadLine());
                    multi4 = b50 * 50;
                    Console.WriteLine("Valor total: Q" + multi4);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "5":
                    Console.Clear();
                    Console.WriteLine("Billetes de 100.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b100 = Convert.ToDouble(Console.ReadLine());
                    multi5 = b100 * 100;
                    Console.WriteLine("Valor total: Q" + multi5);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "6":
                    Console.Clear();
                    Console.WriteLine("Billetes de 200.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    b200 = Convert.ToDouble(Console.ReadLine());
                    multi6 = b200 * 200;
                    Console.WriteLine("Valor total: Q" + multi6);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "7":
                    Console.Clear();
                    Console.WriteLine("Monedas de 5 centavos.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    m5 = Convert.ToDouble(Console.ReadLine());
                    multi7 = m5 * 0.05;
                    Console.WriteLine("Valor total: Q" + multi7);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "8":
                    Console.Clear();
                    Console.WriteLine("Monedas de 10 centavos.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    m10 = Convert.ToDouble(Console.ReadLine());
                    multi8 = m10 * 0.10;
                    Console.WriteLine("Valor total: Q" + multi8);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "9":
                    Console.Clear();
                    Console.WriteLine("Monedas de 25 centavos.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    m25 = Convert.ToDouble(Console.ReadLine());
                    multi9 = m25 * 0.25;
                    Console.WriteLine("Valor total: Q" + multi9);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "10":
                    Console.Clear();
                    Console.WriteLine("Monedas de 50 centavos.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    m50 = Convert.ToDouble(Console.ReadLine());
                    multi10 = m50 * 0.5;
                    Console.WriteLine("Valor total: Q" + multi10);
                    opcion = "0";

                    Console.ReadKey();
                    break;

                case "11":
                    Console.Clear();
                    Console.WriteLine("Monedas de 1 quetzal.\n");

                    Console.WriteLine("Ingrese la cantidad: ");
                    m100 = Convert.ToDouble(Console.ReadLine());
                    multi11 = m100 * 1;
                    Console.WriteLine("Valor total: Q" + multi11);
                    opcion = "0";

                    Console.ReadKey();
                    break;
            }
        }
    }
}