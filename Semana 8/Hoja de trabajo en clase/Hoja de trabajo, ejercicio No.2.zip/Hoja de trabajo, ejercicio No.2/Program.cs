﻿using System;


    class Program
    {
        static void Main(string[] args)
        {
         
            Console.Write("Ingrese el numero de ventas: ");
            int n = int.Parse(Console.ReadLine());

            decimal[] ventas = new decimal[n]; 

            for (int i = 0; i < n; i++)
            {
                Console.Write($"Venta {i + 1}: Q");
                ventas[i] = decimal.Parse(Console.ReadLine()); 
            }

            int mayor = 0; 
            int medio = 0; 
            int menor = 0; 
            decimal totalmayor = 0; 
            decimal totalmedio = 0; 
            decimal totalmenor = 0; 
            decimal total = 0; 

            for (int i = 0; i < n; i++)
            {
                if (ventas[i] > 1300)
                {
                    mayor++;
                    totalmayor += ventas[i];
                }
                else if (ventas[i] > 300)
                {
                    medio++;
                    totalmedio += ventas[i];
                }
                else
                {
                    menor++;
                    totalmenor += ventas[i];
                }

                total += ventas[i]; 
            }

           
            Console.WriteLine("\nReporte de ventas:");
            Console.WriteLine($"Precio mayor a Q1300: {mayor} ventas, Q{totalmayor:N2}");
            Console.WriteLine($"Precio entre Q301-Q1300: {medio} ventas, Q{totalmedio:N2}");
            Console.WriteLine($"Precio menor a Q300: {menor} ventas, Q{totalmenor:N2}");
            Console.WriteLine($"Total: {n} ventas, Q{total:N2}");
        }
    }
