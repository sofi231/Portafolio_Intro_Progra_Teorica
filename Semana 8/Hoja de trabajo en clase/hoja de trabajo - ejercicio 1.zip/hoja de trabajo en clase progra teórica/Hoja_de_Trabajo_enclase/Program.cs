﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1 - ahorros");

        double suma = 0;
        double n = 0;
        int cont = 0;

        Console.WriteLine("Ingrese sus ahorros por mes");
        do
        {
            Console.Write("> ");
            n = Convert.ToDouble(Console.ReadLine());
            suma = suma + n;
            cont++;
        }
        while (cont < 12);
        Console.WriteLine("EL total de sus ahorros es: " + suma);

    }      


}