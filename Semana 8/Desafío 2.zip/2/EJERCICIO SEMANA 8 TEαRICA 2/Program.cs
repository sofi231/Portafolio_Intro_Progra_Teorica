﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 2\n");

        double dias = 0;
        double sueldo = 0;
        double horas = 0, suma = 0, multi = 0;
        int cont = 0;
        char respuesta = 's';

        do
        {

            Console.WriteLine("Ingrese los días trabajados por semana:");
            dias = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese las horas por día que trabajó: ");
            horas = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese cuánto gana por hora: ");
            sueldo = Convert.ToDouble(Console.ReadLine());

            multi = (sueldo * horas) * dias;
            cont++;

            suma = suma + multi;

            Console.WriteLine("\nDesea ingresar los datos de otro empleado: s = sí, n = no ");
            respuesta = Convert.ToChar(Console.ReadLine());

        } while (respuesta == 's');

        Console.WriteLine("\nLo que pagó la empresa por el total de empleados es: " + "Q" + suma + "\n");
    }
}
