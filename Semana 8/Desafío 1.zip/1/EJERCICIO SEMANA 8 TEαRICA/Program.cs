﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1\n");
        int pago = 10;
        int total = 0;

        for (int i = 1; i <= 20; i++)
        {
            Console.WriteLine("el mes " + i + " pagó: " + "Q" + pago);
            pago = pago * 2;
            total = total + pago;
        }
        Console.WriteLine("\nEl total que pagó es: Q" + total + "\n");
    }
}