﻿using System;

class Program
{

    static void Main(string[] args)
    {

        Console.WriteLine("Trabajo Semana 7 - Ana Sofía Asturias To - 1078123");
        Console.WriteLine("Ejercicio 1");

        double t = 0;
        double c = 0;

        Console.WriteLine("\nIngresa diez numeros que sean mayores a 0");
        while (c < 10)
        {
            double n = Convert.ToDouble(Console.ReadLine());

            if (n > 0)
            {
                t = t + n;
                c++;
            }
            else
            {
                Console.WriteLine("\nDebe ingresar un numero mayor que 0, vuelva a intentar");
            }
        }
        double p = (double)t / c;
        Console.WriteLine("\nEl promedio de los 10 números es: " + p);
        Console.ReadKey();

        Console.Clear();
        Console.WriteLine("Trabajo Semana 7 - Ana Sofía Asturias To - 1078123");
        Console.WriteLine("\nEjercicio 2");
        Console.WriteLine("Primeros 10 números primos");

        int nu = 2;
        while (nu < 30) 
        {
            bool f = true;

            for (int i = 2; i <= Math.Sqrt(nu); i++)
            {
                if (nu % i == 0)
                {
                    f = false;
                    break;
                }    
            }
            if (f)
            {
                Console.WriteLine(nu + " ");
            }

            nu++;
        }
        Console.ReadKey();
        
    }
}