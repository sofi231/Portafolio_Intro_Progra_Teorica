﻿using System;

namespace EjercicioClase
{
    class Program
    {
        static void Main(string[] args)
        {
            double[,] temp = new double[7, 2];
            string[] dias = new string[7];
            double[] promM = new double[5];
            double tempMaxTarde = double.MinValue;
            double tempMinManana = double.MaxValue;
            int contTempManana = 0;
            int contTempTarde = 0;

            Console.WriteLine("Ingrese los días de la semana");

            for (int f = 0; f < 7; f++)
            {
                dias[f] = Console.ReadLine();

                for (int c = 0; c < 2; c++)
                {
                    Random r = new Random();
                    temp[f, c] = r.Next(0, 4);
                }
            }

            Console.WriteLine("Temperaturas registradas:");

            for (int f = 0; f < 7; f++)
            {
                Console.Write(dias[f] + ": ");
                double tempManana = temp[f, 0];
                double tempTarde = temp[f, 1];
                Console.Write($"Mañana: {tempManana}, Tarde: {tempTarde}\n");

                if (tempManana < tempMinManana)
                {
                    tempMinManana = tempManana;
                }

                if (tempTarde > tempMaxTarde)
                {
                    tempMaxTarde = tempTarde;
                }

                if (tempManana < 30)
                {
                    contTempManana++;
                }

                if (tempTarde < 30)
                {
                    contTempTarde++;
                }
            }

            Console.WriteLine();

            for (int f = 2; f < 7; f++)
            {
                double sumaManana = 0;
                for (int c = 0; c < 2; c++)
                {
                    sumaManana += temp[f, c];
                }

                promM[f - 2] = sumaManana / 2;
            }

            double promedioTarde = 0;
            for (int f = 0; f < 7; f++)
            {
                promedioTarde += temp[f, 1];
            }
            promedioTarde /= 2;

            Console.WriteLine($"Promedio de temperatura de los últimos 3 días de la mañana: {promM[2]}");

            Console.WriteLine($"El día más caluroso por la tarde es:");

            for (int f = 0; f < 7; f++)
            {
                if (temp[f, 1] == tempMaxTarde)
                {
                    Console.WriteLine(dias[f]);
                }
            }

            Console.WriteLine($"El día menos caluroso por la mañana es:");

            for (int f = 0; f < 7; f++)
            {
                if (temp[f, 0] == tempMinManana)
                {
                    Console.WriteLine(dias[f]);
                }
            }

            Console.WriteLine($"Cantidad de días con temperatura menor a 30 grados por la mañana: {contTempManana}");
            Console.WriteLine($"Cantidad de días con temperatura menor a 30 grados por la tarde: {contTempTarde}");

            if (promedioTarde > 30)
            {
                Console.WriteLine("Es una temporada calurosa");
            }
            else
            {
                Console.WriteLine("No es una temporada calurosa");
            }
            Console.ReadKey();
        }
    }
}