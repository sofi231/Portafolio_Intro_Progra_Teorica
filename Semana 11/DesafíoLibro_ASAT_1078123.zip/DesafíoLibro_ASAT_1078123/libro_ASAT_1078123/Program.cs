﻿using System;

public class Libro
{
    private int codigo, cantidad, pagina, leidas, lectura;
    private string nombre, estado, mensaje;
    private double porcentaje;

    public int Codigo { get { return codigo; } }
    public int Cantidad { get { return cantidad; } }
    public int Leidas { get { return leidas; } }
    public int Pagina { get { return pagina; } }
    public string Nombre { get { return nombre; } }
    public string Estado { get { return estado; } }

    public Libro(int codigo, string nombre, int cantidad, string estado)
    {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.leidas = 0;
        this.estado = estado;
    }

    public void Leer(int paginas)
    {
        if (paginas <= 0)
        {
            Console.WriteLine("Error: La cantidad de páginas a leer debe ser mayor a cero.");
        }
        else if (leidas + paginas > cantidad)
        {
            Console.WriteLine("Error: La cantidad de páginas a leer supera la cantidad de páginas del libro.");
        }
        else
        {
            leidas += paginas;
            
            if (leidas == cantidad)
            {
                estado = "Leido";
                
            }
        }
    }

    public double ObtenerPorcentajeLectura()
    {
        return ((double)leidas / cantidad) * 100;
    }

    public int ObtenerPaginaActual()
    {
        return leidas++;
    }

    public void MostrarLibro()
    {
        Console.WriteLine($"\nCódigo: {codigo}");
        Console.WriteLine($"Nombre: {nombre}");
        Console.WriteLine($"Cantidad de páginas: {cantidad}");
        Console.WriteLine($"Porcentaje de lectura: {ObtenerPorcentajeLectura():0.00}%");
        Console.WriteLine($"Páginas leídas: {leidas}");
        
    }

    public static void Main()
    {
        Libro libro = new Libro(1, "", 500, "");
        libro.MostrarLibro();

        libro.Leer(150);
        libro.MostrarLibro();

        libro.Leer(200);
        libro.MostrarLibro();

    }

}